## CS 542 - Assignment 5

Name - Jerome Dinal Herath Muthukumaranage
Name - Esraa Aldreabi
Name - Robert Valenti 

Assuming you are in the directory containing this README:

## Initial steps:
Before cleaning, compiling & running follow the steps below:
    1. navigate into the directory fileVisitors starting from
    the directory containing the README.txt
        (use cd fileVisitors from terminal for linux)

## To clean:
ant -buildfile src/build.xml clean

--------------------------------------------------------
## To compile: 
ant -buildfile src/build.xml all

--------------------------------------------------------
## To run by specifying arguments from command line

ant -buildfile src/build.xml run -Darg0=src/input.txt -Darg1=src/output.txt -Darg2=0

(assuming the input file is "input.txt" and "output.txt" the output file 
within the src/ directory)

The input parameter for -Darg2 should be integer values between 0 & 4.
Each integer value would trigger different logger levels.

    0 - No output would be printed on terminal.(output will be written to file only)
    1 - prints when a palindrome is found.
    2 - prints when a word with primeLength is found.
    3 - prints when tree in ascending order.
    4 - prints when the classes are constructed. 

-----------------------------------------------------------------------

"We have done this assignment completely on our own. We have not copied
it, nor have we given my solution to anyone else. We understand that if
we are involved in plagiarism or cheating we will have to sign an
official form that we have cheated and that this form will be stored in
our official university record. We also understand that we will receive a
grade of 0 for the involved assignment for our first offense and that we
will receive a grade of F for the course for any additional
offense.”

[Date:11/20/2017 ]
Esraa Aldreabi
Jerome Dinal Herath
Robert Valenti
-----------------------------------------------------------------------

## justification for Data Structures & Time Complexity

Data Structure : Binary Search Tree
                 
find Nodes(search) : Θ(log(n)) (Average case)
Insert Nodes(insert) : Θ(log(n)) (Average case)

No delete operation for nodes is implemented, since at no point would an
inserted Node(for words) would be deleted from the tree.

Lexicographical ordering of the words were used as the identifier 
for each node in the BST where lowercase and uppercase letters were considered different.
For a given text document it is highly unlikely that all words would be completely in 
ascending or descending order simply because of common conjunction words used in text 
and because of the case-difference considered. Therefore the average case would
occur most of the time.

-----------------------------------------------------------------------



