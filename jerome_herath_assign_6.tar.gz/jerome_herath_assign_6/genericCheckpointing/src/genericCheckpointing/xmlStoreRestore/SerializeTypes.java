package genericCheckpointing.xmlStoreRestore;

import genericCheckpointing.util.MyLogger;
import genericCheckpointing.util.MyLogger.DebugLevel;

public class SerializeTypes
{
    /**
     *constructor
     **/
    public SerializeTypes(){}

    /**
     *serilizes class 
     *@param the class name
     *@return serialized string
     **/
    protected String serializeClass(String sIn){
	return "<complexType xsi:type=\"genericCheckpointing.util."+sIn+"\">";
    }

    /**
     *converts to string based on the type and value
     *@param type, the String type
     *@param value, the value of the object
     *@return stringified string
     **/
    public String convertToString(String type, Object value){
	String output = "";
	try{
	    if(type.equals("myInt")){
		output = serializeMyInt(value);
	    }else if(type.equals("myLong")){
		output = serializeMyLong(value);
	    }else if(type.equals("myString")){
		output = serializeMyString(value);
	    }else if(type.equals("myBool")){
	       output = serializeMyBool(value);
	    }else if(type.equals("myOtherInt")){  
		output = serializeMyOtherInt(value);
	    }else if(type.equals("myOtherLong")){
		output = serializeMyOtherLong(value);
	    }else if(type.equals("myDoubleT")){
		output = serializeMyDouble(value);
	    }else if(type.equals("myOtherDoubleT")){
		output = serializeMyOtherDouble(value);
	    }else if(type.equals("myFloatT")){
		output = serializeMyFloat(value);
	    }else if(type.equals("myShortT")){
		output = serializeMyShort(value);
	    }else if(type.equals("myOtherShortT")){
		output = serializeMyOtherShort(value);
	    }else if(type.equals("myCharT")){
		output = serializeMyChar(value);
	    }else{
	        throw new RuntimeException("error: unknown type");
	    }
	}catch(RuntimeException e){
	    e.printStackTrace();
	    System.exit(1);
	}finally{}
	return output;
    }

    //--------- private serialization functions ----------------------

    private String serializeMyInt(Object value){
	String s = String.valueOf(value);
	Integer temp = Integer.parseInt(s);
	//System.out.println("int temp : "+temp);
	if(temp < 10){
	    //temp = 0;
	    return "";
	}
	return " <myInt xsi:type=\"xsd:int\">"+(int)value+"</myInt>";
    }
    
    private String serializeMyOtherInt(Object value){
	String s = String.valueOf(value);
	Integer temp = Integer.parseInt(s);
	if(temp < 10){
	    //temp = 0;
	    return "";
	}
	return "  <myOtherInt xsi:type=\"xsd:int\">"+(int)value+"</myOtherInt>";
    }
    
    private String serializeMyLong(Object value){
	String s = String.valueOf(value);
	Long temp = Long.parseLong(s);
	if(temp < 10.0){
	    return "";
	    //return " <myLong xsi:type=\"xsd:long\">0</myLong>";
	}
	return " <myLong xsi:type=\"xsd:long\">"+temp+"</myLong>";
    }

    private String serializeMyOtherLong(Object value){
	String s = String.valueOf(value);
	Long temp = Long.parseLong(s);
	//System.out.println("temp:"+(Long)value);
	if(temp < 10.0){
	    return "";
	    //return "  <myOtherLong xsi:type=\"xsd:long\">0</myOtherLong>";	  
	}
	return "  <myOtherLong xsi:type=\"xsd:long\">"+temp+"</myOtherLong>";
    }
    
    private String serializeMyString(Object value){
	return " <myString xsi:type=\"xsd:string\">"+(String)value+"</myString>";
    }

    private String serializeMyBool(Object value){
	return " <myBool xsi:type=\"xsd:boolean\">"+(Boolean)value+"</myBool>";
    }

    private String serializeMyDouble(Object value){
	String s = String.valueOf(value);
	Double temp = Double.parseDouble(s);
	if(temp < 10.0){
	    //temp = 0.0;
	    return "";
	}
	return " <myDoubleT xsi:type=\"xsd:double\">"+temp+"</myDoubleT>";
    }

    private String serializeMyOtherDouble(Object value){
	String s = String.valueOf(value);
	Double temp = Double.parseDouble(s);
	if(temp < 10.0){
	    //temp = 0.0;
	    return "";
	}
	return "  <myOtherDoubleT xsi:type=\"xsd:double\">"+temp+"</myOtherDoubleT>";
    }

    private String serializeMyFloat(Object value){
	return " <myFloatT xsi:type=\"xsd:float\">"+(float)value+"</myFloatT>";
    }

    private String serializeMyShort(Object value){
	return " <myShortT xsi:type=\"xsd:short\">"+value+"</myShortT>";
    }

    private String serializeMyOtherShort(Object value){
	return "  <myOtherShortT xsi:type=\"xsd:short\">"+value+"</myOtherShortT>";
    }

    private String serializeMyChar(Object value){
	return " <myCharT xsi:type=\"xsd:char\">"+value+"</myCharT>";
    }
  
    
}
