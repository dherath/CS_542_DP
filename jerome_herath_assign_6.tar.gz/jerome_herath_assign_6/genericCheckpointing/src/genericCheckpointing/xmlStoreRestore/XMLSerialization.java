package genericCheckpointing.xmlStoreRestore;

import java.lang.reflect.Field;
import genericCheckpointing.util.SerStrategyI;
import genericCheckpointing.util.FileProcessor;
import genericCheckpointing.util.MyLogger;
import genericCheckpointing.util.MyLogger.DebugLevel;

public class XMLSerialization implements SerStrategyI
{
    private FileProcessor fileproc;
    SerializeTypes serializeT = null;

    /**
     *constructor
     *@param fileprocessor
     **/
    public XMLSerialization(FileProcessor fpIn){
	this.fileproc = fpIn;
	this.serializeT = new SerializeTypes();
    }

    /**
     *processes input and writes to file
     *@param obj, the Object
     **/
    @Override
    public void processInput(Object obj){
	try{
	    Class className = obj.getClass();
	    fileproc.writeLine("<DPSerialization>");
	    fileproc.writeLine(serializeT.serializeClass(className.getSimpleName()));
	    Field[] fields = className.getDeclaredFields();
	    for(int i=0; i<fields.length; i++){
		String type = fields[i].getName();
		fields[i].setAccessible(true);
		Object val = fields[i].get(obj);
		fileproc.writeLine(serializeT.convertToString(type,val));
	    }
	    fileproc.writeLine("</complexType>");
	    fileproc.writeLine("</DPSerialization>");
	}catch(IllegalArgumentException | IllegalAccessException e){
	    e.printStackTrace();
	    System.exit(0);
	}finally{}
    }
}
