package genericCheckpointing.util;

import java.util.Random;

public class MyAllTypesFirst extends SerializableObject
{
    private int myInt;
    private long myLong;
    private String myString;
    private boolean myBool;
    private int myOtherInt;
    private long myOtherLong;

    /**
     *empty constructor
     **/
    public MyAllTypesFirst(){}

    /**
     *constructor
     *@params 
     **/
    public MyAllTypesFirst(int myInt,Long myLong,String myString,boolean myBool,int myOtherInt,Long myOtherLong){
	this.myInt = myInt;
	this.myLong = myLong;
	this.myString = myString;
	this.myBool = myBool;
	this.myOtherInt = myOtherInt;
	this.myOtherLong = myOtherLong;
    }

    //------ get methods --------------------------

    /**
     *get for myInt
     *@return myInt
     **/
    public int getMyInt(){
	return myInt;
    }

    /**
     *get MyLong
     *@return myLong
     **/
    public long getMyLong(){
	return myLong;
    }

    /**
     *gets MyString
     *@return myString
     **/
    public String getMyString(){
	return myString;
    }

    /**
     *gets MyBool
     *@return myBool
     **/
    public boolean getMyBool(){
	return myBool;
    }

    /**
     *gets myOtherInt
     *@return myOtherInt
     */
    public int getMyOtherInt(){
	return myOtherInt;
    }

    /**
     *gets myOtherLong
     *@return myOtherLong
     **/
    public long getMyOtherLong(){
	return myOtherLong;
    }

    //----- set methods --------------------

    /**set method for myInt
     *@param myInt
     **/
    public void setMyInt(int myIntIn){
	this.myInt = myIntIn;
    }

    /**
     *setter for myLong
     *@param myLong value
     **/
    public void setMyLong(long myLongIn) {
	this.myLong = myLongIn;
    }

    /**
     *setter for myString
     *@param mySTring value
     **/
    public void setMyString(String myStringIn) {
	this.myString = myStringIn;
    }

    /**
     *setter for myBool
     *@param Boolean value
     **/
    public void setMyBool(boolean myBoolIn) {
	this.myBool = myBoolIn;
    }

    /**
     *setter for myOtherInt
     *@param the myOther INt value
     **/    
    public void setMyOtherInt(int myOtherIntIn){
	this.myOtherInt = myOtherIntIn;
    }

    /**
     *setter for myOtherlong
     *@param long value
     **/
    public void setMyOtherLong(long myLongOtherIn) {
	this.myOtherLong = myLongOtherIn;
    }


    //-------------- overriden Methods -------------------
    /**
     *toString function
     *@return data to String
     **/
    @Override
    public String toString(){
	String temp = "myInt: "+myInt+" | myLong: "+myLong+" | myString: "+myString+" | myBool: "+myBool+" | myOtherInt: "+myOtherInt+" | myOtherLong: "+myOtherLong+"\n";
	return temp;
    }

    /**
     * equals function
     *@param the object
     *@return true, if equal
     **/
    @Override
    public boolean equals(Object obj){
	//----------------------------
	if (this == obj)
	    return true;
	if (obj == null)
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	//----------------------------
	MyAllTypesFirst temp = (MyAllTypesFirst) obj;
	if (myBool != temp.getMyBool())
	    return false;
	if (myInt != temp.getMyInt())
	    return false;
	if(myOtherInt != temp.getMyOtherInt())
	    return false;
	if (myLong != temp.getMyLong())
	    return false;
	if(myOtherLong != temp.getMyOtherLong())
	if (myString == null) {
	    if (temp.getMyString() != null)
		return false;
	} else if (!myString.equals(temp.getMyString()))
	    return false;
	return true;
    }

    /**
     *hashcode function
     *@return a unique key
     **/
    @Override
    public int hashCode(){
	final int pv = 107;
	int temp = 1;
	temp += pv*myInt;
	temp = pv * temp - (myBool ? -10 : 10);
	temp += myOtherInt + pv*myString.length();
	temp +=  myLong >> 16;
	temp += Math.pow(temp,myOtherLong << 2) * pv;
	return temp;
    }
    
}
