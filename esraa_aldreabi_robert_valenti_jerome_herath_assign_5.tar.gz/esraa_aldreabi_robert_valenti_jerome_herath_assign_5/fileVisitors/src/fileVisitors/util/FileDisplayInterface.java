package fileVisitors.util;

public interface FileDisplayInterface{
    void writeToFile();
}
