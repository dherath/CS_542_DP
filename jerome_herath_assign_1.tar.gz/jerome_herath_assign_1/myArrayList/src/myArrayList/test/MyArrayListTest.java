package myArrayList.test;

import myArrayList.util.Results;
import myArrayList.MyArrayList;

public class MyArrayListTest
{
    /**
     *invokes 10 test cases on an instance of MyArrayList
     *@param myArraylist the MyArraylist instance ant results the Results instance
     **/
    public void testMe(MyArrayList myArrayList,Results results){
	String temp;
	//---test case 1-----------
	if(isSizeCorrect(myArrayList)){
	    temp="passed";
	}else{
	    temp="failed";
	}
	results.storeNewResult("\ntest 1 : isSizeCorrect() "+temp);
	temp="";
	//---test case 2-----------
	if(isSumCorrect(myArrayList)){
	    temp ="passed";
	}else{
	    temp ="failed";
	}
	results.storeNewResult("\ntest 2 : isSumCorrect() "+temp);
	temp="";
	//---test case 3-----------
	if(isMyArrayListSorted(myArrayList)){
	    temp ="passed";
	}else{
	    temp ="failed";
	}
	results.storeNewResult("\ntest 3 : isMyArraylistSorted() "+temp);
	temp="";
	//---test case 4-----------
	if(testSortedAfterInsertion(myArrayList)){
	    temp ="passed";
	}else{
	    temp ="failed";
	} 
	results.storeNewResult("\ntest 4 : testSortedAfterInsertion() "+temp);
	temp="";
	//---test case 5-----------
	if(testEdgecaseInsertions(myArrayList)){
	    temp ="passed";
	}else{
	    temp ="failed";
	} 
	results.storeNewResult("\ntest 5 : testEdgecaseInsertions() "+temp);
	temp="";
	//---test case 6-----------
	if(testForExistingValue(myArrayList)){
	    temp ="passed";
	}else{
	    temp ="failed";
	} 
	results.storeNewResult("\ntest 6 : testForExistingValue() "+temp);
	temp="";
	//---test case 7-----------
	if(testNonExistingValue(myArrayList)){
	    temp ="passed";
	}else{
	    temp ="failed";
	} 
	results.storeNewResult("\ntest 7 : testNonExistingValue() "+temp);
	temp="";
	//---test case 8-----------
	if(isRemoveValueCorrect(myArrayList)){
	    temp ="passed";
	}else{
	    temp ="failed";
	} 
	results.storeNewResult("\ntest 8 : isRemoveValueCorrect() "+temp);
	temp="";
	//---test case 9-----------
	if(testSortedAfterRemoval(myArrayList)){
	    temp ="passed";
	}else{
	    temp ="failed";
	} 
	results.storeNewResult("\ntest 9 : testSortedAfterRemoval() "+temp);
	temp="";
	//---test case 10-----------
	if(testToStringFormat(myArrayList)){
	    temp ="passed";
	}else{
	    temp ="failed";
	} 
	results.storeNewResult("\ntest 10: testToStringFormat() "+temp);
	temp="";
    }

    //-------------------------------------------
    //  Test Methods
    //-------------------------------------------

    /**
     *test case 1: if size() returns the correct number
     *@param xIn the instance of MyArrayList
     *@return true if size() is correct
     **/
    private boolean isSizeCorrect(MyArrayList xIn){
	int[] a = xIn.getArray();
	int size1 = xIn.size();
	int size2=0;
	boolean flag = true;
	for(int i=0;i<a.length;i++){
	    if(flag){
		if(a[i]!=0){
		    flag = false;
		}
	    }else{
		if(a[i]==0 && size1==size2){
		    return true;
		}
	    }
	    size2++;    
	}
	return false;
    }
    
    /**
     *test case 2 : check if sum() is correct given correct input
     *@param xIn the MyArrayList instance and rIn the results instance
     *@return true if sum matches
     **/
    private boolean isSumCorrect(MyArrayList xIn){
	int[] array = xIn.getArray();
	int sum1 = xIn.sum();
	int sum2 = 0;
	for(int i=0;i<xIn.size();i++){
	    sum2 += array[i];
	}
	if(sum1==sum2){
	    return true;
	}
	return false;
    }

    /**
     *test case 3: checks if the MyArrayList is already sorted
     *@param the instance of MyArrayList
     *@return true if sorted
     **/
    private boolean isMyArrayListSorted(MyArrayList xIn){
	int[] temp = xIn.getArray();
	for(int i=0;i<xIn.size()-1;i++){
	    if(temp[i]>temp[i+1]){
		return false;
	    }
	}
	return true;
    }

    /**
     *test case 4: tests if array is sorted after every insertion of a new value
     *@param the instance of MyArrayList
     *@return true if MyArrayList gets sorted after every turn
     **/
    private boolean testSortedAfterInsertion(MyArrayList t){
	int temp = 10;
	boolean result = true;
	while(temp<60){
	    t.insertSorted(temp);
	    temp +=20;
	    if(this.isMyArrayListSorted(t)==false){
		result= false;
	    }
	    t.removeValue(temp-20);
	    if(t.getRepeatedCount()>1){
		for(int i=0;i<t.getRepeatedCount()-1;i++){
		    t.insertSorted(temp-20);
		}
	    }
	}
	return result;
    }

    /**
     *test 5: if values < 0 and >10000 are ignored in insertSorted
     *@param xIn the instance of MyArrayList
     *@return true if edge cases are ignored
     **/
    private boolean testEdgecaseInsertions(MyArrayList t){
	int temp1 = -25;
	int temp2 = 2345678;
	t.insertSorted(temp1);
	t.insertSorted(temp2);
	int[] a = t.getArray();
	for(int i=0;i<t.size();i++){
	    if(a[i]==temp1 | a[i]==temp2){
		return false;
	    }
	}
	return true;
    }

    /**
     *test 6: evaluates indexOf() provided an exisiting value is input
     *@param xIn the instance of MyArrayList
     *@return true if indexes match
     **/
    private boolean testForExistingValue(MyArrayList xIn){
	int a[] = xIn.getArray();
	int val =a[xIn.size()/2];
	int index1 = xIn.indexOf(val);
	int index2=0;
	while(a[index2]!=val){
	    index2++;
	}
	if(index1==index2){
	    return true;
	}
	return false;
    }

    /**
     *test case 7: evaluates indexOf() provided for a non-exisiting input
     *@param xIn the instance of MyArraylist
     *@return true if result is -1 from indexOf()
     **/
    private boolean testNonExistingValue(MyArrayList xIn){
	int val = 0;
	int count=0;
	int a[] = xIn.getArray();
	boolean flag = true;
	while(flag){
	    count =0;
	    for(int i=0;i<xIn.size();i++){
		if(a[i]==val){
		    break;
		}
		count++;
	    }
	    if(count==xIn.size()){
		flag=false;
	    }else{
		val++;
	    }
	    
	}
	if(xIn.indexOf(val)==-1){
	    return true;
	}
	return false;
    }

    /**
     *test case 8:checks if removeValue() removes all insances of an existing integer
     *@param xIn the instance of MyArraylist
     *@return true if value is removed
     **/
    private boolean isRemoveValueCorrect(MyArrayList t){
	boolean result = false;
	int[] a = t.getArray();
	int val = a[t.size()/2];
	t.removeValue(val);
	int repeats = t.getRepeatedCount();
	if(t.indexOf(val)==-1){
	    result = true;
	}
	for(int i=0;i<repeats;i++){
	    t.insertSorted(val);		
	}
	return result;
    }

    /**
     *test case 9: tests if array is sorted after removal
     *@param xIn the instance of MyArraylist
     *@return true if array is sorted
     **/
    private boolean testSortedAfterRemoval(MyArrayList t){
	boolean result = false;
	int[] a = t.getArray();
	int val = a[t.size()/2];
	t.removeValue(val);
	int repeats = t.getRepeatedCount();      
	if(this.isMyArrayListSorted(t)){
	    result = true;
	}
	for(int i=0;i<repeats;i++){
	    t.insertSorted(val);		
	}	
	return result;
    }

    /**
     *test case 10: if the same string is generated from toString()
     *@param xIn the insance of MyArraylist
     *@return true if compared strings are the same
     **/
    private boolean testToStringFormat(MyArrayList t){
	String str1 = t.toString();
	int[] a = t.getArray();
	String str2 ="[ ";
	for(int i=0;i<t.size()-1;i++){
	    str2 += a[i]+", ";
	}	
	str2 += a[t.size()-1]+" ]";
	if(str1.equals(str2)){
	    return true;
	}
	return false;	
    }     
}
