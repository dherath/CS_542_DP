package myArrayList;

import myArrayList.util.FileProcessor;
import java.lang.IllegalArgumentException;

public class  MyArrayList
{
    private int[] array;
    private int index; // count for elements
    private int temp;
    private FileProcessor file;
    private String line;
    private boolean hasInvalidInput;// flag to identify if an invalid input is present
    private int repeatCount;// flag for successive removals for the same integer
    
    /**
     *constructor
     **/
    public MyArrayList(String s){
        file = new FileProcessor(s);
	array = new int[50];
	index = 0;
	hasInvalidInput = false;
	try{
	    line = file.readLine();
	    while(line!=null){
		if(line.trim().length()>0 && this.isLineValid(line)){
		    temp = this.convertToInt(line);
		    insertSorted(temp);
		}
		line = file.readLine();
	    }
	    if(index==0 && !hasInvalidInput){
		throw new RuntimeException("input.txt is empty");
	    }
	    if(index==0 && hasInvalidInput){
		throw new RuntimeException("all values in input.txt are not valid");
	    }
    
	}catch(RuntimeException e){
	    e.printStackTrace();
	    System.exit(1);
	}finally{
	    if(this.hasInvalidInput){
		System.out.println("the text file contained invalid inputs, all such values were ignored");
	    }
	    file.closeAll();	    
	}
    }

    /**
     *inserts value while maintaining sorted order
     *@param the new value to be entered
     **/
    public void insertSorted(int newValue){
	try{
	    if(newValue>=0 && newValue<=10000){
		if(index>=array.length){
		    array = this.resizeArray();
		}
		int nextIndex = this.findNextPosition(newValue);       
		for(int i=index;i>nextIndex;i--){
		    array[i]=array[i-1];
		}
		array[nextIndex]=newValue;
		this.index++;
	    }
	}catch(IllegalArgumentException e){
	    e.printStackTrace();
	    System.exit(1);
	}finally{}
    }

    /**
     *removes all occurances of a given integer and maintains sorted order
     *@param the value to be removed
     **/
    public void removeValue(int value){
	try{
	    this.repeatCount =0;
	    int i = this.indexOf(value);
	    if(i !=-1){
		int count = 1;
		while(array[i+count]==value && i+count<index){
		    count++;// finds number of values
		}
		this.repeatCount = count;
		this.index -= count;//resets index
		for(int k=i;k<index;k++){
		    array[k]=array[k+count];//sorts array
		}
	    }	    
	}catch(IllegalArgumentException e){
	    e.printStackTrace();
	    System.exit(1);
	}finally{}
    }
    
    /**
     *return the index of the first encounter of a value
     *@param the value to be searched
     *@return the index of the value, -1 if not found
     **/ 
    public int indexOf(int value){
	try{
	    for(int i=0;i<this.size();i++){
		if(array[i]==value){
		    return i;
		}
	    }
	}catch(IllegalArgumentException e){
	    e.printStackTrace();
	    System.exit(1);
	}finally{}
	return -1;
    }
    
    /**
     *finds the number of stored values
     *@return the number of values stored
     **/
    public int size(){
	return index;
    }

    /**
     *finds the sum of all the integers in arrayList
     *@retun the summation
     **/
    public int sum(){
	int sum =0;
	for(int i=0;i<this.size();i++){
	    sum+= array[i];
	}
	return sum;
    }

    /**
     *prints out the sorted datastructure
     *@retun the datastructure in String format
     **/
    public String toString(){
	String list ="[ ";
	for(int i=0;i<this.size()-1;i++){
	    list +=this.array[i]+", ";
	}	
	list+=this.array[this.size()-1]+" ]";
	return list;
    }


    /**
     *get method for integer array
     *@return the array
     **/
    public int[] getArray(){
	return this.array;
    }

    /**
     *gets the number of removals done for the most recent removed int value
     *@return the number of copies deleted
     **/ 
    public int getRepeatedCount(){
	return this.repeatCount;
    }
    
    //--------------------------------------------------------------
    //  Helper functions
    //--------------------------------------------------------------

    /**
     *finds if a string input can be converted to a positive Int
     *@param str the String input
     *@return true if the format is valid
     **/
    private boolean isLineValid(String str){
	String temp ="0123456789";
	int count;
	for(int i=0;i<str.length();i++){
	    count =0;
	    for(int j=0;j<temp.length();j++){
		if(str.charAt(i)==temp.charAt(j)){
		    count++;   
		}
	    }
	    if(count<1){
		hasInvalidInput=true;
		return false;
	    }
	}
	return true;
    }

    /**
     *Converts the string input to an Int
     *@param str the String input which is a number
     *@return the number in Int format
     **/
    private int convertToInt(String str){
	int number=0;
	for(int i=0;i<str.length();i++){
	    number = number*10+str.charAt(i)-'0';
	}
	return number;
    }

    /**
     *finds the next position for the value to be entered
     *@param the input Int value
     *@return the next insertion index
     **/
    private int findNextPosition(int xIn){
	int tempIndex =0;
	while(xIn>this.array[tempIndex] && tempIndex<index){
	    tempIndex++;
	}
	return tempIndex; 
    }

    /**
     *resizes and copies elements to new array  when array is full
     *@return the newArray with half the size increased
     **/
    private int[] resizeArray(){
	int[] newArray = new int[array.length + array.length/2];
	for(int i=0;i<array.length;i++){
	    newArray[i]=array[i];
	}
	return newArray;
    }	
}
