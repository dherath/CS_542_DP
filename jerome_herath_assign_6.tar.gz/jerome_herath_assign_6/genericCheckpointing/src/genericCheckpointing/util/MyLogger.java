package genericCheckpointing.util;

public class MyLogger{
    // the logger was used in initial debugging of code
    // however since there is no user argument for debug levels
    // those clauses have been removed from final version

    /*DEBUG_VALUE=4 [Print to stdout everytime a constructor is called]
      DEBUG_VALUE=3 [Print to stdout the process followed]
      DEBUG_VALUE=2 [Print to stdout the count of objects compared]
      DEBUG_VALUE=1 [Print to stdout the ignored int,long,double values]
      DEBUG_VALUE=0 [No output should be printed from the applicatio to stdout. It is ok to write to the output file though" ]
    */

    public static enum DebugLevel {RELEASE, VALUE, COUNT, PRINT, CONSTRUCTOR};
    private static DebugLevel debugLevel;

    /**
     *sets the debug value
     *@param levelIn, the debug level
     **/
    public static void setDebugValue (int levelIn){
	switch (levelIn){
	case 4: debugLevel = DebugLevel.CONSTRUCTOR; break;
	case 3: debugLevel = DebugLevel.PRINT; break;
	case 2: debugLevel = DebugLevel.COUNT; break;
	case 1: debugLevel = DebugLevel.VALUE; break;
	case 0: debugLevel = DebugLevel.RELEASE; break;
	}
    }

    /**
     *sets the debug value
     *@param levelIn, the debug level 
     **/
    public static void setDebugValue (DebugLevel levelIn){
	debugLevel = levelIn;
    }

    /**
     *prints the debug message
     *@param message, the message
     *@param levelIn, the debug level
     **/
    public static void writeMessage (String  message, DebugLevel levelIn ){
	if (levelIn == debugLevel){
	    System.out.println(message);
	}
    }

    /**
     * @return String
     */
    public String toString(){
	return "Debug Level is " + debugLevel;
    }
}
