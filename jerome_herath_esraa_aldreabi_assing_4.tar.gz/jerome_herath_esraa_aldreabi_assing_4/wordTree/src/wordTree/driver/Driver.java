package wordTree.driver;

import wordTree.binarySearchTree.TreeInterface;
import wordTree.binarySearchTree.BinarySearchTree;
import wordTree.threadMgmt.CreateWorkers;
import wordTree.store.Results;
import wordTree.util.FileProcessor;
import wordTree.util.TreeBuilder;
import wordTree.util.WordCalculator;
import wordTree.util.MyLogger;
import wordTree.util.MyLogger.DebugLevel;

public class Driver
{

    /**
     *Main
     **/
    public static void main(String[] args){
	try{
	    if(!validateArgs(args)){
		throw new RuntimeException("number of arguments not sufficant.\nRetry with exactly 5 arguments using the following format with absolute paths for files:\n-Darg0=target for input file\n-Darg1=target for output file\n-Darg2= logger level between 0 & 4.\n(0-REALESE,1-FROM_RESULTS,2-IN_RESULTS,3-IN_RUN,4-CONSTRUCTOR)\n-Darg3=number of threads(1-3)\n-Darg4=words to be deleted seperated by spaces\n");
	    }
	    
	    MyLogger.setDebugValue(Integer.parseInt(args[2]));
	    CreateWorkers c=new CreateWorkers();
	    FileProcessor f=new FileProcessor(args[0]);
	    TreeInterface b=new BinarySearchTree();
		
	    c.startWorkers(Integer.parseInt(args[3]),b,f,args[4]);
		
	    WordCalculator w=new WordCalculator();
	    w.countAllValues(b.returnRoot());

	    //System.out.println(w.getDistinctWordNum());			
	    //System.out.println(w.getAllWordNum());	
	    //System.out.println(w.getCharNum());	
		
	    Results output = new Results(args[1]);
		
	    output.storeNewResult("The total number of words: "+w.getAllWordNum()+"\n" );
	    output.storeNewResult("The total number of characters: "+ w.getCharNum()+"\n");
	    output.storeNewResult("The total number of distinct words: "+w.getDistinctWordNum()+"\n" );
	    
	    output.writeToFile();
	}catch(RuntimeException e){
	    e.printStackTrace();
	    System.exit(0);
	}finally{}
    }
    
    /**
     *validates if arguments are correct
     *@param the input arguments
     *@return true if all pass
     **/
    private static boolean validateArgs(String[] args){
	//args[0] -> input file
	//args[1] -> output file name
	//args[2] -> logger level
	//args[3] -> no.of threads
	//args[4] -> delete words
	if(args.length != 5){
	    return false;	
	}
	for(int i = 0; i<args.length ; i++){
	    if(args[i].equals("${arg"+i+"}")){
		return false;
	    }
	}
	int temp1 = Integer.parseInt(args[2]);
	if(temp1 < 0 || temp1 > 4){
	    return false;
	}
	int temp2 = Integer.parseInt(args[3]);
	if(temp2 < 1 || temp2 > 3){
	    return false;
	}
	return true;
    }
}

