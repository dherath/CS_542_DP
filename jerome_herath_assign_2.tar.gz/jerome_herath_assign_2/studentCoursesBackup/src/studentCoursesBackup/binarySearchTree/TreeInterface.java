package studentCoursesBackup.binarySearchTree;

import studentCoursesBackup.myTree.Node;

public interface TreeInterface
{
    Node find(int index);
    void insertNode(Node newNode);
    String printNodes();
}
