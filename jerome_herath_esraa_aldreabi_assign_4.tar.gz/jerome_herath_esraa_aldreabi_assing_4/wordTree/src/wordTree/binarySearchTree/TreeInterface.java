package wordTree.binarySearchTree;

import wordTree.binarySearchTree.Node;

public interface TreeInterface
{
    void insert(String input); // inserts a new node, or incremnes count if repeated word
    boolean delete(String word); // deletes word or reduces the occuronce
    Node search(String word); // finds existance of word
    Node returnRoot();
}
