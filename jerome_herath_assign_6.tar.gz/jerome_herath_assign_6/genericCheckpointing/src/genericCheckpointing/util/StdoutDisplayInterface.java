package genericCheckpointing.util;

public interface StdoutDisplayInterface{
    void writeToStdout(String s);
}
