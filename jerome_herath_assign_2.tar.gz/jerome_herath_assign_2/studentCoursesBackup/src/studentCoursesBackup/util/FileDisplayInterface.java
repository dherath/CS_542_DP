package studentCoursesBackup.util;

public interface FileDisplayInterface{
    void writeToFile();
}
