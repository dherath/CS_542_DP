package airportSecurityState.util;

public interface StdoutDisplayInterface{
    void writeToStdout(String s);
}
