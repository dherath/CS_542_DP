package wordTree.threadMgmt;

import wordTree.binarySearchTree.TreeInterface;
import wordTree.util.FileProcessor;
import wordTree.util.MyLogger;
import wordTree.util.MyLogger.DebugLevel;

public class CreateWorkers {

    /**
     *Constructor
     **/
    public CreateWorkers(){
	MyLogger.writeMessage("in CONSTRUCTOR CreateWorkers",DebugLevel.CONSTRUCTOR);
    }

    /**
     *starts worker threads
     *@param noOfthreads, the number of threads
     *@param b, the instance of a tree Interface
     *@param dWord, the words to be deleted
     **/
    public void startWorkers(int noOfThreads,TreeInterface b,FileProcessor f,String dWord){
	String[] deleteWords=  dWord.split(" ");
	Thread[] thread=new Thread[noOfThreads];
	if(deleteWords.length!=thread.length){
	    System.out.println("The number of threads and delete word don't match");
	    System.exit(1);
	}
	//--------------Insert operation--------------------------------------------
    	for(int i=0;i<noOfThreads;i++) {
		thread[i]=new Thread(new PopulateThread( b,f));
		thread[i].start();
    		
	    }
    	for (int i = 0; i < noOfThreads; i++) {
	    try {
		thread[i].join();
	    } catch (InterruptedException e) {
	        e.printStackTrace();
	        System.exit(1);
	    }
	}
    	//-------------delete operation---------------------------------------------
    	for(int i=0;i<noOfThreads;i++){
	    thread[i]=new Thread(new DeleteThread( b,deleteWords[i]));
	    thread[i].start();    		
	}
    	for (int i = 0; i < noOfThreads; i++){
	    try{
		thread[i].join();
	    }catch (InterruptedException e){
	        e.printStackTrace();
	        System.exit(1);
	    }
	}
    }
}

