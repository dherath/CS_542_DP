package fileVisitors.driver;

import fileVisitors.visitor.PopulateVisitor;
import fileVisitors.visitor.PrimeLength;
import fileVisitors.visitor.PrintTree;
import fileVisitors.visitor.VisitorI;
import fileVisitors.visitor.PalindromeHighlight;
import fileVisitors.binarySearchTree.TreeI;
import fileVisitors.binarySearchTree.TreeHelper;
import fileVisitors.util.MyLogger;
import fileVisitors.store.Results;

public class Driver 
{

    public static void main(String[] args){
	try{
	    if(!validateArgs(args)){
		throw new RuntimeException("number of arguments not sufficant.\nRetry with exactly 3 arguments using the following format with absolute paths for files:\n-Darg0=target for input file\n-Darg1=target for output file\n-Darg2= logger level between 0 & 4\n");
	    }
	    int DEBUG_VALUE = Integer.parseInt(args[2]);
	    MyLogger.setDebugValue(DEBUG_VALUE);

	    TreeI tree = new TreeHelper();
	    VisitorI populate = new PopulateVisitor(args[0]);
	    VisitorI palindrome = new PalindromeHighlight();
	    VisitorI prime = new PrimeLength();
	    VisitorI print = new PrintTree(args[1]);

	    tree.accept(populate);
	    tree.accept(palindrome);
	    tree.accept(prime);
	    tree.accept(print);
	    
	}catch(RuntimeException e){
	    e.printStackTrace();
	    System.exit(0);
	}finally{}
    }

    /**
     *validates if arguments are correct
     *@param the input arguments
     *@return true if all pass
     **/
    private static boolean validateArgs(String[] args){
	//args[0] -> input file name
	//args[1] -> output file name
	//args[2] -> logger level
	if(args.length != 3){
	    return false;	
	}
	for(int i = 0; i<args.length ; i++){
	    if(args[i].equals("${arg"+i+"}")){
		return false;
	    }
	}
	int temp1 = Integer.parseInt(args[2]);
	if(temp1 < 0 || temp1 > 4){
	    return false;
	}
	return true;
    }
}
