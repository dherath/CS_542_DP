package airportSecurityState.util;

public interface FileDisplayInterface{
    void writeToFile();
}
