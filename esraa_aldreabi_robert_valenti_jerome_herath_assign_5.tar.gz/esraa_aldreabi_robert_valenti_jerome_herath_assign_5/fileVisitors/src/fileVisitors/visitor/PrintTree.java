package fileVisitors.visitor;

import fileVisitors.visitor.VisitorI;
import fileVisitors.binarySearchTree.TreeI;
import fileVisitors.binarySearchTree.Node;
import fileVisitors.util.MyLogger;
import fileVisitors.util.MyLogger.DebugLevel;
import fileVisitors.store.Results;

public class PrintTree implements  VisitorI
{
    private String words;
    private Results output;

    /**
     *constructor
     *@param outputfilename, the output file name
     **/
    public PrintTree(String outputFileName){
	words = "";
	MyLogger.writeMessage("initiated PrintTree",DebugLevel.CONSTRUCTOR);
	output = new Results(outputFileName);		
    }

    /**
     *visit function to print the tree
     *@param tree, the instance of the tree
     **/
    public void visit(TreeI tree){
	print_helper(tree.getRoot());
	output.storeNewResult(words);
	output.writeToFile();
    }

    /**
     *helper function to print word in node
     *@param n, the node
     **/
    private void print_helper(Node n){
	if(n == null){
	    return;
	}else{
	    print_helper(n.getLeft());
	    //System.out.println(n.getWord());
	    words += n.getWord()+"\n";
	    MyLogger.writeMessage(n.getWord(),DebugLevel.PRINT);
	    print_helper(n.getRight());
	}
    }

	
}
