## CS 542 - Assignment 4

Name - Jerome Dinal Herath Muthukumaranage
Name - Esraa Aldreabi

Assuming you are in the directory containing this README:

## Initial steps:
Before cleaning, compiling & running follow the steps below:
    1. navigate into the directory wordTree starting from
    the directory containing the README.txt
        (use cd wordTree from terminal for linux)

## To clean:
ant -buildfile src/build.xml clean

--------------------------------------------------------
## To compile: 
ant -buildfile src/build.xml all

--------------------------------------------------------
## To run by specifying arguments from command line

ant -buildfile src/build.xml run -Darg0=src/input.txt -Darg1=src/output.txt -Darg2=0 -Darg3=2 -Darg4="delete words"

(assuming the input file is "input.txt" and "output.txt" the output file 
within the src/ directory)

The input parameter for -Darg2 should be integer values between 0 & 4.
Each integer value would trigger different logger levels.

    0 - No output would be printed on terminal.(output will be written to file only)
    1 - Shows results that are computed
    2 - prints when results are written to file.
    3 - prints when threads are invoked.
    4 - prints when the classes are constructed.  
    
The input parameters for -Darg3 is the number of threads(between 1 & 3) and  
for -Darg4 it should be the words to be deleted separated by spaces.

1)  place the text file within the src folder for the exact commands to work.
    Otherwise please note that the absolute path for  files must be given.
2)  Assuming the output.txt files were not present at runtime then the     
    program will create such text files within the specified path.Even then 
    the absolute path must be given.

--------------------------------------------------------
## Note:

Note that the number of threads should exactly match the number of words passed
on to -Darg4, if not then an error message is shown and the program exits. For cases
where any of the arguments are invalid, an exception is thrown and the program exits.
If the input file is empty, the program throws an exception and exits. Here an input file
with only white-spaces are considered as empty as well.

--------------------------------------------------------
"We have done this assignment completely on our own. We have not copied
it, nor have we given my solution to anyone else. We understand that if
we are involved in plagiarism or cheating we will have to sign an
official form that we have cheated and that this form will be stored in
our official university record. We also understand that we will receive a
grade of 0 for the involved assignment for our first offense and that we
will receive a grade of F for the course for any additional
offense.”

[Date: 11/08/2017]

--------------------------------------------------------

## justification for Data Structures & Time Complexity

Data Structure : Binary Search Tree
                 
find Nodes(search) : Θ(log(n)) (Average case)
Insert Nodes(insert) : Θ(log(n)) (Average case)
Space Complexity : O(n)

No delete operation for nodes is implemented, since at no point would an
inserted Node(for words) would be deleted from the tree.

Lexicographical ordering of the words were used as the identifier 
for each node in the BST where lowercase and uppercase letters were considered different.
For a given text document it is highly unlikely that all words would be completely in 
ascending or descending order simply because of common conjunction words used in text 
and because of the case-difference considered. Therefore the average case would
occur most of the time.



