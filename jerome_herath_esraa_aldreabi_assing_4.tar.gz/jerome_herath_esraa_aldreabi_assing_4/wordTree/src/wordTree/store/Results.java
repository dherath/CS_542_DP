package wordTree.store;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import wordTree.util.StdoutDisplayInterface;
import wordTree.util.FileDisplayInterface;
import wordTree.util.MyLogger;
import wordTree.util.MyLogger.DebugLevel;

public class Results {

    private String text;
    private String outputFileName = null;
    private FileWriter fileWriter = null;
    private BufferedWriter bufferedWriter = null;

    /**
     *constructor
     *@param the name of the output file
     **/
    public Results(String name){
	MyLogger.writeMessage("in CONSTRUCTOR Results",DebugLevel.CONSTRUCTOR);
	text = "";
	this.outputFileName = name;
    }
    
    /**
     *Displays the text in terminal
     *@param the string to be displayed
     **/ 
    public void writeToStdout(String s) {
	System.out.println(s);
    }

    /**
     *prints output to output.txt
     **/
    public void writeToFile(){
	try{
	    fileWriter = new FileWriter(outputFileName);
	    bufferedWriter = new BufferedWriter(fileWriter);
	    bufferedWriter.write(this.getResults());
	    MyLogger.writeMessage("output from Results written to file",DebugLevel.IN_RESULTS);
	}catch(IOException e){
	    e.printStackTrace();
	}finally{
	    try{
		bufferedWriter.close();
		fileWriter.close();
	    }catch(IOException f){
		f.printStackTrace();
	    }
	}
    }

    /**
     *method to get results
     *@return the results text
     **/
    public String getResults(){
	return this.text;
    }

    /**
     *method to set Results
     *@param the new resutls string
     **/
    public void storeNewResult(String s){
	MyLogger.writeMessage("Stored in Results: "+s,DebugLevel.FROM_RESULTS);
	this.text += s;
    }
}

