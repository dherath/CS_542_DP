package genericCheckpointing.xmlStoreRestore;

import java.lang.reflect.Method;
import java.util.regex.Pattern;

import genericCheckpointing.util.FileProcessor;
import genericCheckpointing.util.MyAllTypesFirst;
import genericCheckpointing.util.MyAllTypesSecond;
import genericCheckpointing.util.SerializableObject;
import genericCheckpointing.util.MyLogger;
import genericCheckpointing.util.MyLogger.DebugLevel;

public class DeserializeTypes
{
    private FileProcessor fileproc;

    /**
     *COnstructor
     *@param fIn, fileprocessor instance
     **/
    public DeserializeTypes(FileProcessor fIn){
	this.fileproc = fIn;
    }

    /**
     *creates Object
     *@return the serialized object
     **/
    public SerializableObject createObject(){
	boolean updateFlag = true;
	Class<?> cls = null;
	SerializableObject obj = null;
	Method method = null;
	String line = "";
	while((line=fileproc.readLine()) != null){
	    //------ conditions -----------------
	    if(line.equals("<DPSerialization>") && !updateFlag){
		//System.out.println("inside true flag");
		updateFlag = true;
		continue;
	    }
	    if(line.equals("</DPSerialization>") && updateFlag){
		//System.out.println("inside false-flag");
		updateFlag = false;
		break;
		}
	    //-----------------------------------
	    if(updateFlag){
		try{
		    if(line.contains("complexType") && !line.contains("/")){
			String clsType = getxsiType(line);
			cls = Class.forName(clsType);
			obj = (SerializableObject) cls.newInstance();
			//System.out.println("created serialized Object");			
		    }else if(line.contains("myInt")){
			//System.out.println("found int");
			method = cls.getDeclaredMethod("setMyInt", int.class);
			//System.out.println("declared method");
			method.invoke(obj, Integer.parseInt(extractData(line)));
			//System.out.println("set int");
		    }else if(line.contains("myLong")){
			method = cls.getDeclaredMethod("setMyLong", long.class);
			method.invoke(obj, Long.parseLong(extractData(line)));
		    }else if(line.contains("myString")){
			method = cls.getDeclaredMethod("setMyString", String.class);
			method.invoke(obj, extractData(line));
		    }else if(line.contains("myBool")){
			method = cls.getDeclaredMethod("setMyBool", boolean.class);
			method.invoke(obj, Boolean.parseBoolean(extractData(line)));
		    }else if(line.contains("myOtherInt")){
			method = cls.getDeclaredMethod("setMyOtherInt", int.class);
			method.invoke(obj, Integer.parseInt(extractData(line)));
		    }else if(line.contains("myOtherLong")){
			method = cls.getDeclaredMethod("setMyOtherLong", long.class);
			method.invoke(obj, Long.parseLong(extractData(line)));
		    }else if(line.contains("myDoubleT")){
			method = cls.getDeclaredMethod("setMyDoubleT", double.class);
			method.invoke(obj, Double.parseDouble(extractData(line)));
		    }else if(line.contains("myOtherDoubleT")){
			method = cls.getDeclaredMethod("setMyOtherDoubleT", double.class);
			method.invoke(obj, Double.parseDouble(extractData(line)));
		    }else if(line.contains("myFloatT")){
			method = cls.getDeclaredMethod("setMyFloatT", float.class);
			method.invoke(obj, Float.parseFloat(extractData(line)));
		    }else if(line.contains("myShortT")){
			method = cls.getDeclaredMethod("setMyShortT", short.class);
			method.invoke(obj, Short.parseShort(extractData(line)));
		    }else if(line.contains("myOtherShortT")){
			method = cls.getDeclaredMethod("setMyOtherShortT", short.class);
			method.invoke(obj, Short.parseShort(extractData(line)));
		    }else if(line.contains("myCharT")){
			method = cls.getDeclaredMethod("setMyCharT", char.class);
			method.invoke(obj, (extractData(line)).charAt(0));
		    }		    
		}catch(Exception e){
		    e.printStackTrace();
		    System.exit(0);
		}finally{}
	    }
	}
	return obj;
    }

    //------- helper functions ------------------
    
    /**
     *gets the xsi: type from a string
     *@param the string
     *@return the String type name
     **/
    private String getxsiType(String sIn){
	//System.out.println(sIn);
	String[] temp = sIn.split("=");
	String output = temp[1].replace("\"","");
	//System.out.println(output);
	return output.replace(">", "");
    }

    private String extractData(String sIn){
	String output = "";
	boolean flag = false;
	for(int i=0; i< sIn.length()-1; i++){
	    char temp = sIn.charAt(i);
	    if(sIn.charAt(i)=='>' && !flag){
		flag = true;
		continue;
	    }
	    if(sIn.charAt(i)=='<' && flag){
		flag = false;
		break;
	    }
	    if(flag){
		output += temp;
	    }
	}
	//System.out.println(output);
	return output;
    }
}
