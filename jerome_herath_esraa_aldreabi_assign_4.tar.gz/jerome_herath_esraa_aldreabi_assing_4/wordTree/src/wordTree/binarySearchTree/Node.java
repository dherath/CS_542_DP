package wordTree.binarySearchTree;

import wordTree.util.MyLogger;
import wordTree.util.MyLogger.DebugLevel;

public class Node {
    private String word;
    private int count;
    Node leftChild;
    Node rightChild;

    /**
     *constructor
     *@param word, the word to be stored
     *@param count, the number of instances
     **/
    public Node(String word,int count) {
	MyLogger.writeMessage("in CONSTRUCTOR Node",DebugLevel.CONSTRUCTOR);
	setWord(word);
	setCount(count);
	leftChild=rightChild=null;
    }

    /**
     *gets left child
     *@return the left child
     **/
    public Node getLeftChild() {
	return leftChild;
    }

    /**
     *sets left child
     *@param, the left child
     **/
    public void setLeftChild(Node leftChild) {
	this.leftChild = leftChild;
    }

    /**
     *gets right child
     *@return the right child
     **/
    public Node getRightChild() {
	return rightChild;
    }

    /**
     *sets the right child
     *@param the right child
     **/
    public void setRightChild(Node rightChild) {
	this.rightChild = rightChild;
    }

    /**
     *gets the stored word
     *@return the word
     **/
    public String getWord() {
	return word;
    }

    /**
     *sets the word
     *@param the word
     **/
    public void setWord(String word) {
	this.word = word;
    }

    /**
     *gets the number fo instances of word
     *@return the count
     **/
    public int getCount() {
	return this.count;
    }

    /**
     *set intial count
     *@param te count
     **/
    public void setCount(int count) {
	this.count=count;
    }

    /**
     *increment count
     **/
    public void incCount() {
	this.count++;
    }

    /**
     *reduce the count
     **/
    public void decCount() {
	this.count--;
    }
}
