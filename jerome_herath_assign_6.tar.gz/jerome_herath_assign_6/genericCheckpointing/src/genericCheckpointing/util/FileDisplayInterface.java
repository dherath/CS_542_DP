package genericCheckpointing.util;

public interface FileDisplayInterface{
    void writeToFile();
}
