package fileVisitors.visitor;

import fileVisitors.visitor.VisitorI;
import fileVisitors.binarySearchTree.TreeI;
import fileVisitors.util.FileProcessor;

public class PopulateVisitor implements VisitorI {

    private String inputFileName;
    private String line;
    
    /**
     *constructor
     *@param filename, the input file name
     **/
    public PopulateVisitor(String fileName){
	inputFileName=fileName;
    }
    
    
    /**
     *builds the tree from input file data
     *@param the instance of the empty tree
     **/
    private void BuildTree(TreeI tree){
	try{
	    FileProcessor inputFile=new FileProcessor(inputFileName);
	    line = inputFile.readLine();
	    while(line !=null){
		if(line.trim().length() >0){
		    String[] items=  line.split(" ");
		    for(int i=0;i<items.length;i++){	
			if(items[i].trim().length()>0){
			    tree.insert(items[i]);
			}
		    }
		}

		line = inputFile.readLine();
	    }
	}catch(RuntimeException e){
	    e.printStackTrace();
	    System.exit(0);
	}finally{}
		
    }

    /**
     *visit function to populate 
     *@param the instance of the tree
     **/
    @Override
    public void visit(TreeI tree) {		
	BuildTree(tree);
    }


}


