package fileVisitors.visitor;

import fileVisitors.visitor.VisitorI;
import fileVisitors.binarySearchTree.Node;
import fileVisitors.binarySearchTree.TreeI;
import fileVisitors.util.MyLogger;
import fileVisitors.util.MyLogger.DebugLevel;

public class PalindromeHighlight implements  VisitorI{

    /**
     *Constructor
     **/
    public PalindromeHighlight(){
	MyLogger.writeMessage("initiated PalindromeHighlight",DebugLevel.CONSTRUCTOR);
    }

    /**
     *visit function-> for palindromes
     *@param the instance fo the tree
     **/
    public void visit(TreeI tree){
	if(tree.getRoot() != null){
	    updateTree(tree.getRoot());   
	}
    }

    /**
     *private update function for palindrome words
     *@param the node n
     **/
    private void updateTree(Node n){
	
	if(n == null){
	    return;
	}
	updateTree(n.getLeft());
	updateTree(n.getRight());
	if(ifPalindrome(n.getWord()) && n.getWord().length() > 3){
	    //System.out.println("FOUND PALINDROME: "+ n.getWord());
	    MyLogger.writeMessage("found palindrome: "+n.getWord(),DebugLevel.PALINDROME);
	    //String new_word = ;
	    n.setWord(n.getWord().toUpperCase());
	}	
    }

    /**
     *finds if word is a palindrom
     *@param word, the word
     *@return true is palindrome else fasle
     **/
    private boolean ifPalindrome(String word){

	for(int i=0;i<word.length()/2;i++){
	    if(word.charAt(i) != word.charAt(word.length()-i-1)){
		return false;
	    }
	}
	return true;
    }
}
