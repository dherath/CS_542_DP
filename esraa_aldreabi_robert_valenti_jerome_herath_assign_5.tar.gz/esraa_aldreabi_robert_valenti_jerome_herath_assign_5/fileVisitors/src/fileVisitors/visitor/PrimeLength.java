package fileVisitors.visitor;

import fileVisitors.visitor.VisitorI;
import fileVisitors.binarySearchTree.TreeI;
import fileVisitors.binarySearchTree.Node;
import fileVisitors.util.MyLogger;
import fileVisitors.util.MyLogger.DebugLevel;

public class PrimeLength  implements  VisitorI
{

    /**
     *constructor
     **/
    public PrimeLength(){
	MyLogger.writeMessage("initiated PrimeLength",DebugLevel.CONSTRUCTOR);
    }

    /**
     *visit function for primeLength
     *@param tree, the instance of the tree
     **/
    public void visit(TreeI tree){
	prime_helper(tree.getRoot());
    }

    /**
     *changes word in Node if prime length
     *@param n, the instance of the node
     **/
    private void prime_helper(Node n){
	if(n == null){
	    return;
	}else{
	    if(isPrime(n.getLength())){
		MyLogger.writeMessage("found PrimeLength word: "+n.getWord(),DebugLevel.PRIME);
		String s = n.getWord().concat("-PRIME");
		n.setWord(s);
	    }
	    prime_helper(n.getLeft());
	    prime_helper(n.getRight());
	}
    }

    /**
     *find if word lenght is prime
     *@param n, the length of the word
     *@return true if prime, else false
     **/
    private boolean isPrime(int n){
	for(int i =2; i < n; i++){
	    if(n % i == 0){
		return false;
	    }
	}

	return true;
    }

}
