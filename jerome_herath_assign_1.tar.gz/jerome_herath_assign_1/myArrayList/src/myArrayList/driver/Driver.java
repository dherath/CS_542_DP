package myArrayList.driver;

import myArrayList.util.FileProcessor;
import myArrayList.util.Results;
import myArrayList.test.MyArrayListTest;
import myArrayList.MyArrayList;

public class Driver 
{

    public static void main(String[] args) {

	// Name - Jerome Dinal Herath Muthukumaranage
	// Bno - B00708543
	
	MyArrayList myList = new MyArrayList(args[0]);
	Results results = new Results(args[1]);
	MyArrayListTest test = new MyArrayListTest();
	
	results.writeToStdout("sorted myArrayList of size("+myList.size() +") :\n"+myList.toString());
	results.storeNewResult("The sum of all the values in the array list is: "+myList.sum());
	
	test.testMe(myList,results);
       
	results.writeToFile(results.getResults());

    }	
}
