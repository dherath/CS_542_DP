package wordTree.util;
import wordTree.binarySearchTree.TreeInterface;
import wordTree.util.FileProcessor;
import wordTree.util.MyLogger;
import wordTree.util.MyLogger.DebugLevel;

public class TreeBuilder
{
	
    private String line; // line read

    /**
     *Constructor
     **/
    public TreeBuilder(){
	line = "";
	MyLogger.writeMessage("in CONSTRUCTOR TreeBuilder",DebugLevel.CONSTRUCTOR);
    }

    /**
     *builds the tree from the input file
     *@param b, the binary search tree instance
     *@param inputFile, the file processor for input file
     **/
    public void treeBuilder(TreeInterface b,FileProcessor inputFile){
	try{
	    int count = 0;
	    line = inputFile.readLine();
	    while(line !=null){
		if(line.trim().length()!=0){
		    String[] items=  line.split(" ");				
		    for(int i=0;i<items.length;i++){	
			    b.insert(items[i]);
			}
		}else{
		    count--;
		}
		count++;
		line = inputFile.readLine();
	    }
	    if(count==0){
		throw new RuntimeException("the input file is empty");
	    }
	}catch(RuntimeException e){
	    e.printStackTrace();
	    System.exit(0);
	}finally{}	
    }    
}
