package genericCheckpointing.util;

import genericCheckpointing.util.SerializableObject;

public interface SerStrategyI
{
    void processInput(Object obj);
}
