package fileVisitors.binarySearchTree;

import java.lang.StringBuilder;
import fileVisitors.binarySearchTree.Node;
import fileVisitors.binarySearchTree.TreeI;
import fileVisitors.util.MyLogger;
import fileVisitors.visitor.VisitorI;


public class TreeHelper implements TreeI
{
    private Node root;

    /** 
     * Class constructor.
     */
    public TreeHelper(){
	root = null;
	MyLogger.writeMessage("initiated TreeHelper", MyLogger.DebugLevel.CONSTRUCTOR);
    }

    public Node getRoot(){
	return root;
    }
    /** 
     * Inserts a node into a tree, if the tree is empty, it makes the node the root
     * @param new_word - word to be inserted
     */

    public void insert(String new_word){
	if(root == null){
	    Node new_node = new Node(new_word);
	    root = new_node;
	    return;
	}

	Node current_node = root;
	int result;  
	while(true){
	    result = new_word.compareTo(current_node.getWord());
	    if(result < 0){
		if(current_node.getLeft() != null){
		    current_node = current_node.getLeft();
		    continue;
		}else{
		    Node new_node = new Node(new_word);
		    current_node.setLeft(new_node);
		    return;
		}
	    }else if(result > 0){
		if(current_node.getRight() != null){
		    current_node = current_node.getRight();
		    continue;
		}else{
		    Node new_node = new Node(new_word);
		    current_node.setRight(new_node);
		    return;
		}
	    }else if(result == 0){
		return; 
	    }
	}
    }


    /** 
     * Finds if a node is in a tree
     * @param - s - word of the Node to be looked up
     * @return - Node if it is found, else null
     */
    public Node findNode(String s){
	if(root == null){
	    return null;
	}

	Node current_node = root;
	int result;  
	while(true) {
	    result = s.compareTo(current_node.getWord());
	    if(result < 0){
		if(current_node.getLeft() != null){
		    current_node = current_node.getLeft();
		    continue;
		}else{
		    return null;
		}
	    }else if(result > 0){
		if(current_node.getRight() != null){
		    current_node = current_node.getRight();
		    continue;
		}else{
		    return null;
		}
	    }else if(result == 0) {
		return current_node;
	    }
	}
    }

    public void accept(VisitorI v){
	v.visit(this);
    }

    /** 
     * Prints the nodes in the tree
     * @return - The Nodes in string format Bnum:courses Ex. 1234:ABCDE, seperated by new lines
     */
    public String toString(){
	StringBuilder sb = new StringBuilder();

	if(root != null){
	    toString_helper(root,sb);
	}
	return sb.toString();
    }


    /** 
     * Recursive helper for the to_string (iterates through the tree in order and calls each toString)
     * @param - curr - the current node to get the toString of
     * @param sb - the StringBuilder object which is appending all of the toStrings in order 
     */
    private void toString_helper(Node curr, StringBuilder sb){
	if(curr.getLeft() != null){
	    toString_helper(curr.getLeft(), sb);
	}

	String s = curr.toString();
	if(s != null){
	    sb.append(curr.toString()+ "\n");
	}

	if(curr.getRight() != null){
	    toString_helper(curr.getRight(),sb);
	}
    }
}
