package fileVisitors.visitor;
import fileVisitors.binarySearchTree.TreeI;

public interface VisitorI {
    public void visit(TreeI tree);
}
