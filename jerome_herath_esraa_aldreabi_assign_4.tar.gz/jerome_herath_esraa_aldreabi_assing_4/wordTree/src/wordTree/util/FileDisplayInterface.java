package wordTree.util;

public interface FileDisplayInterface{
    void writeToFile();
}
