package genericCheckpointing.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import genericCheckpointing.util.MyLogger;
import genericCheckpointing.util.MyLogger.DebugLevel;


public class FileProcessor {

    private String inputFileName=null;
    private File inputFile=null;
    private FileReader fileReader=null;
    private FileWriter fileWriter = null;
    private BufferedReader bufferedReader=null;
    private BufferedWriter bufferedWriter = null;
    private boolean operationType;
	    
    /**
     * constructor
     *@param s, the absolute file path
     **/
    public FileProcessor(String s){
	this.inputFileName = s;
    }

    /**
     *creates Writer
     **/
    public void createWriter(){
	try {
	    bufferedWriter = new BufferedWriter(new FileWriter(inputFileName)); 
	} catch (IOException e) {
	    e.printStackTrace();
	    System.exit(0);
	}
	
    }

    /**
     *creates reader
     **/
    public void createReader(){
	try {
	    bufferedReader = new BufferedReader(new FileReader(inputFileName));				
	} catch (IOException e) {
	    e.printStackTrace();
	    System.exit(0);
	}
    }

    /**
     *reads a line from an opened text file
     *@return  returns the line as a String
     **/
    public String readLine() {
	try{
	    return getBufferedReader().readLine();
	} catch (IOException e) {
	    return null;
	} finally {}
    }

    /**
     *returns the current bufferedReader
     *@return the BufferedReader
     **/
    private BufferedReader getBufferedReader(){
	return bufferedReader;
    }

    /**
     *Writes a line to file
     *@param the string to write
     **/
    public void writeLine(String line){
	try{
	    if(!line.equals("")){
		bufferedWriter.write(line);
		bufferedWriter.newLine();
	    }
	}catch(IOException e){
	    e.printStackTrace();
	    System.exit(1);
	}finally{}
    }

    /**
     *closes all opened instances
     **/
    public void closeAll(){
	try{
	    this.bufferedReader.close();
	    this.fileReader.close();	    
	    this.bufferedWriter.close();
	    this.fileWriter.close();
	}catch(IOException e){
	    e.printStackTrace();
	}
    }

    /**
     *closes write
     **/
    public void closeWriter(){
	try{
	    this.bufferedWriter.close();    
	}catch(IOException e){
	    e.printStackTrace();
	}
    }

    /**
     *closes read
     **/
    public void closeReader(){
	try{
	    this.bufferedReader.close();    
	}catch(IOException e){
	    e.printStackTrace();
	}
    }
}
