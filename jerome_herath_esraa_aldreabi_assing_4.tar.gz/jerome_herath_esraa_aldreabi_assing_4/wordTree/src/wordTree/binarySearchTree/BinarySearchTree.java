package wordTree.binarySearchTree;

import wordTree.binarySearchTree.TreeInterface;
import wordTree.binarySearchTree.Node;
import wordTree.util.MyLogger;
import wordTree.util.MyLogger.DebugLevel;

public class BinarySearchTree implements TreeInterface
{

    private Node root; //root node of tree
    

    /**
     *constructor
     **/
    public BinarySearchTree(){
	root = null;
	MyLogger.writeMessage("in CONSTRUCTOR BinarySearchTree",DebugLevel.CONSTRUCTOR);
    }

    //-----------Interface Methods --------------------------------
    
    /**
     *inserts a word into the tree
     *@param the word to be inserted
     **/
    public synchronized void insert(String word){
	Node newNode=new Node(word,1);
	if(root==null){  // If there is no root this becomes root
	    root=newNode;
	}else{
	    Node N=root;
	    Node parent;
	    while(true){        	
		parent=N;
		if(newNode.getWord().compareTo(N.getWord())==0){
		    N.incCount();
		    break;
		}
		//-----------------------
		if(newNode.getWord().compareTo(N.getWord())>0){
		    N=N.leftChild;	
		    if(N==null){// then place the new node on the left of it
			parent.leftChild=newNode;
			break;
		    }
		    if(N.getWord().equals(newNode.getWord())){
			N.incCount();
			break;
		    }		        			 	
		}else{
		    N=N.rightChild;
		    if(N==null){// then place the new node on the right of it
			parent.rightChild=newNode;
			break;		        		
		    }
		    if(N.getWord().equals(newNode.getWord())){
			N.incCount();
			break;
		    }
		}
	    }
	}		
    }

    /**
     *deletes an instance of a word from the tree
     *@param the word to be deleted
     *@return true if deleted, else false
     **/
    public synchronized boolean delete(String word){
	Node d=search(word);
	if(d==null){
	    return false;
	}
	if(d.getCount()>=1){
	    d.decCount();
	    return true;
	}
	if(d.getCount()==0){
	    return false;
	}
	return true;
    }

    /**
     *Search for node with word
     *@param the word to be searched
     *@return the node if found, null otherwise
     **/
    public Node search(String word) {
	Node N=root;     
	while(N.getWord().compareTo(word)!=0){	        	
	    if(N.getWord().compareTo(word)==0){
		return N;
	    }
	    if(N.getWord().compareTo(word)<0){
		N=N.leftChild;
	    }else{
		N=N.rightChild;
	    }		
	    if(N==null){
		return null;
	    }//not in the tree
	}
	return N;
    }

    /**
     *gets root node
     *@return, the root
     **/
    public Node returnRoot(){
	return root;
    }
}

