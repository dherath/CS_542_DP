package fileVisitors.binarySearchTree;
import fileVisitors.binarySearchTree.Node;
import fileVisitors.visitor.VisitorI;

public interface TreeI
{
    public void insert(String new_word);
    public Node findNode(String s);
    public Node getRoot();
    public void accept(VisitorI v);
}
