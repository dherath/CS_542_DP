package wordTree.util;

//import wordTree.binarySearchTree.TreeInterface;
import wordTree.binarySearchTree.Node;
import wordTree.util.MyLogger;
import wordTree.util.MyLogger.DebugLevel;

public class WordCalculator
{
    private int totalWords;
    private int distinctWords;
    private int totalChars;

    /**
     *Constructor
     **/
    public WordCalculator(){
	totalWords = 0;
	totalChars = 0;
	distinctWords = 0;
	MyLogger.writeMessage("in CONSTRUCTOR WordCalculator",DebugLevel.CONSTRUCTOR);
    }

    /**
     *counts all values
     **/
    public void countAllValues(Node N){
	if (N==null) return;

	countAllValues(N.getLeftChild());
	countAllValues(N.getRightChild());

	if(N.getCount()>0) distinctWords++;
	totalChars += N.getCount()*N.getWord().length();
	totalWords += N.getCount();
    }

    /**
     *returns total chars
     *@return tot. chars
     **/
    public int getCharNum(){
	return totalChars;
    }

    /**
     *gets distinct word count
     *@return, no. of distinct words
     **/
    public int getDistinctWordNum(){
	return distinctWords;
    }

    /**
     *gets total words
     *@return tot. word count
     */
    public int getAllWordNum(){
	return totalWords;
    }
}
