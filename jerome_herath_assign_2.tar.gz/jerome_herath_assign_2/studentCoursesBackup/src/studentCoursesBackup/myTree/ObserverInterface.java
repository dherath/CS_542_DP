package studentCoursesBackup.myTree;

public interface ObserverInterface
{
    void update(ObserverInterface oIn,String sIn);// sIn for the course string
}
