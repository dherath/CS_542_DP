package genericCheckpointing.xmlStoreRestore;

import genericCheckpointing.util.SerStrategyI;
import genericCheckpointing.util.FileProcessor;
import genericCheckpointing.util.MyAllTypesFirst;
import genericCheckpointing.util.MyAllTypesSecond;
import genericCheckpointing.util.SerializableObject;
import genericCheckpointing.util.MyLogger;
import genericCheckpointing.util.MyLogger.DebugLevel;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Field;

public class StoreRestoreHandler implements InvocationHandler
{
    FileProcessor fileproc;
    DeserializeTypes deserializeT;

    /**
     *constructor
     *@param file processor
     **/
    public StoreRestoreHandler(FileProcessor fpIn){
	this.fileproc = fpIn;
	deserializeT = new DeserializeTypes(fpIn);
    }

    /**
     *serializes the data from object
     *@param sObj, the object
     *@param strategy, the strategy to serialize
     **/
    public void serializeData(Object sObj,SerStrategyI strategy){
	try{
	    strategy.processInput(sObj);
	}catch(RuntimeException e){
	    e.printStackTrace();
	    System.exit(0);
	}
    }

    /**
     *invokes based on proxy
     *@param proxy, the proxy instance
     *@param method, the method
     *@param args, the array of arguments
     *@return the object, if method is readObj
     **/
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable{
	Object tempObj = null;
	if(method.getName().equals("writeObj")){
	    if(args[2].equals("XML")){
		serializeData(args[0],new XMLSerialization(fileproc));
	    }
	}else if(method.getName().equals("readObj")){
	    tempObj = deserializeT.createObject();
	}
	return tempObj;
    }
}
