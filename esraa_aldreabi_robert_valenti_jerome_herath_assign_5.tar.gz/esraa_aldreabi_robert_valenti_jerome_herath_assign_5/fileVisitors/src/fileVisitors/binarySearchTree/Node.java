package fileVisitors.binarySearchTree;

import java.lang.ArrayIndexOutOfBoundsException;
import java.lang.StringBuilder;
import fileVisitors.util.MyLogger;

public class Node 
{
    private Node left;
    private Node right;
    private String word;

    /** 
     * Class constructor given a file name.
     * @param bNum - bNumber of the student
     */
    public Node(String new_word){
	left = null;
	right = null;
	word = new_word;
	MyLogger.writeMessage("initiated Node", MyLogger.DebugLevel.CONSTRUCTOR);
        
    }


    /** 
     * Accesser of private node left.
     * @return left- the left Node child of this Node
     */
    public Node getLeft(){
	return left;
    }


    /** 
     * Accessor of the private word
     * @return word - string being stored
     */
    public String getWord(){
	return word;
    }

    public void setWord(String s){
	word = s;
    }

    /** 
     * Accessor of the private count
     * @return count -  class counter
     */
    public int getLength(){
	return word.length();
    }
    
    /** 
     * Accesser of private node right.
     * @return right- the right Node child of this Node
     */
    public Node getRight(){
	return right;
    } 

    /** 
     * Setter of private node left.
     * @param l- the Node to set left to
     */
    public void setLeft(Node l){
	if(l != null){
	    left = l;
	}
    }
    /** 
     * Setter of private node right.
     * @param r- the Node to set right to
     */
    public void setRight(Node r){
	if(r != null){
	    right = r;
	}
    }

    /** 
     * Prints the node
     * @return - The Node in string format Bnum:courses Ex. 1234:ABCDE
     */
    public String toString(){
	return "" + word;
    }

}

