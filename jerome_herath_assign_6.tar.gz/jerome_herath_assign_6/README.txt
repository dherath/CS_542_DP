## CS 542 - Assignment 6

Name - Jerome Dinal Herath Muthukumaranage
B number - B00708543
email - jherath1@binghamton.edu

Assuming you are in the directory containing this README:

## Initial steps:
Before cleaning, compiling & running follow the steps below:
    1. navigate into the directory genericCheckpointing starting from
    the directory containing the README.txt
        (use cd genericCheckpointing from terminal for linux)

## To clean:
ant -buildfile src/build.xml clean

--------------------------------------------------------
## To compile: 
ant -buildfile src/build.xml all

--------------------------------------------------------
## To run by specifying arguments from command line

ant -buildfile src/build.xml run -Darg0=serdeser -Darg1=N -Darg2=src/file.txt 

-Darg0 : serdeser or deser mode
-Darg1 : the number of instances needed from each type
-Darg2 : the path to the text file

--------------------------------------------------------
#Note :

-It is assumed when in 'deser' mode, the already present input file would be well formatted
-Depending on the mode in, the arguments for -Darg1,2 have different meaning. In serdeser
mode N, is the number of instances need to be created and file.txt would be the path to 
the output.
-In deser mode, N is the number of instances ot be read from the file & file.txt is the path to 
the input file

--------------------------------------------------------
"I have done this assignment completely on my own. I have not copied
it, nor have I given my solution to anyone else. I understand that if
I am involved in plagiarism or cheating I will have to sign an
official form that I have cheated and that this form will be stored in
my official university record. I also understand that I will receive a
grade of 0 for the involved assignment for my first offense and that I
will receive a grade of F for the course for any additional
offense.”

[Date: 12/08/2017]

--------------------------------------------------------


