package wordTree.threadMgmt;

import wordTree.util.FileProcessor;
import wordTree.util.TreeBuilder;
import wordTree.util.MyLogger;
import wordTree.util.MyLogger.DebugLevel;
import wordTree.binarySearchTree.TreeInterface;

public class PopulateThread implements Runnable
{
    TreeInterface newb;
    FileProcessor inputFile;
    TreeBuilder tb=new TreeBuilder() ; 

    /**
     *Constructor
     *@param b, the instance of Binary Search Tree
     *@param f, the instance of file processor
     **/
    public PopulateThread(TreeInterface b,FileProcessor f){
	newb=b;
	inputFile=f;
	MyLogger.writeMessage("in CONSTRUCTOR PopulateThread",DebugLevel.CONSTRUCTOR);
    }


    /**
     *run method
     **/
    @Override
    public void run(){
	tb.treeBuilder(newb,inputFile);
	MyLogger.writeMessage("in RunThread insert function",DebugLevel.IN_RUN);
    }

}
