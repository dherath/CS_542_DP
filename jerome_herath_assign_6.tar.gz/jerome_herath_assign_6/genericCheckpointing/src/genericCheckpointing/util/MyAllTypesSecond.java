package genericCheckpointing.util;

import java.util.Random;

public class MyAllTypesSecond extends SerializableObject
{
    private double myDoubleT;
    private double myOtherDoubleT;
    private float myFloatT;
    private short myShortT;
    private short myOtherShortT;
    private char myCharT;

    /**
     *empty constructor
     **/
    public MyAllTypesSecond(){}

    /**
     *constructor
     *@params
     **/
    public MyAllTypesSecond(double myDoubleT, double myOtherDoubleT, float myFloatT, short myShortT, short myOtherShortT, char myCharT){
	this.myDoubleT = myDoubleT;
	this.myOtherDoubleT = myOtherDoubleT;
	this.myFloatT = myFloatT;
	this.myShortT = myShortT;
	this.myOtherShortT = myOtherShortT;
	this.myCharT = myCharT;
    }

    //------ get methods --------------------------

    /**
     *get for myDoubleT
     *@return mydoubleT
     **/
    public double getMyDoubleT(){
	return myDoubleT;
    }

    /**
     *get for myOtherDoubleT
     *@return myOtherdoubleT
     **/
    public double getMyOtherDoubleT(){
	return myOtherDoubleT;
    }
    
    /**
     *get MyFloatT
     *@return myFloatT
     **/
    public float getMyFloatT(){
	return myFloatT;
    }

    /**
     *gets MyShort
     *@return myShort
     **/
    public short getMyShortT(){
	return myShortT;
    }

    
    /**
     *gets MyOtherShortT
     *@return myOtherShortT
     **/
    public short getMyOtherShortT(){
	return myOtherShortT;
    }
    
    /**
     *gets myCHarT
     *@return myChart
     */
    public char getMyCharT(){
	return myCharT;
    }

    //----- set methods --------------------

    /**
     *set for myDoubleT
     *@param mydoubleT
     **/
    public void setMyDoubleT(double myDoubleTIn){
	this. myDoubleT = myDoubleTIn;
    }

    /**
     *set for myOtherDoubleT
     *@param myOtherdoubleT
     **/
    public void setMyOtherDoubleT(double myOtherDoubleTIn){
	this. myOtherDoubleT = myOtherDoubleTIn;
    }
    
    /**
     *set MyFloatT
     *@param myFloatT
     **/
    public void setMyFloatT(float myFloatTIn){
	this. myFloatT = myFloatTIn;
    }

    /**
     *sets MyShort
     *@param myShort
     **/
    public void setMyShortT(short myShortTIn){
	this. myShortT = myShortTIn;
    }
    
    /**
     *sets MyOtherShortT
     *@param myOtherShortT
     **/
    public void setMyOtherShortT(short myOtherShortTIn){
        this.myOtherShortT = myOtherShortTIn;
    }
    
    /**
     *sets myCHarT
     *@param myChart
     */
    public void setMyCharT(char myCharTIn){
	this.myCharT = myCharTIn;
    }

    //-------------- overriden Methods -------------------
    /**
     *toString function
     *@return data to String
     **/
    @Override
    public String toString(){
	String temp = "myDoubleT: "+myDoubleT+" | myOtherDoubleT: "+myOtherDoubleT+" | myFloatT: "+myFloatT+" | myShortT: "+myShortT+" | myOtherShortT: "+myOtherShortT+" | myCharT: "+myCharT+"\n";
	return temp;
    }

    /**
     *equals function
     *@param the object
     *@return true if equals
     **/
    @Override
    public boolean equals(Object obj) {
	//------------------------------
	if (this == obj)
	    return true;
	if (obj == null)
	    return false;
	if (getClass() != obj.getClass())
	    return false;
	//------------------------------
	MyAllTypesSecond temp = (MyAllTypesSecond) obj;
	if (myCharT != temp.getMyCharT())
	    return false;
	if (Double.doubleToLongBits(myDoubleT) != Double
	    .doubleToLongBits(temp.getMyDoubleT()))
	    return false;
	if (Double.doubleToLongBits(myOtherDoubleT) != Double
	    .doubleToLongBits(temp.getMyOtherDoubleT()))
	    return false;
	if (Float.floatToIntBits(myFloatT) != Float
	    .floatToIntBits(temp.getMyFloatT()))
	    return false;
	if (myShortT != temp.getMyShortT())
	    return false;
	if (myOtherShortT != temp.getMyOtherShortT())
	    return false;
	return true;
    }

    /**
     *hashcode function
     **/
    @Override
    public int hashCode(){
	final int pv = 107;
	int temp = 1;
	temp += pv*myDoubleT;
	temp += pv *myOtherDoubleT/1000;
	temp += myFloatT + pv*myShortT;
	temp = pv * temp + myOtherShortT;
	temp = pv * myCharT + temp;
	return temp;	
    }
    
}
