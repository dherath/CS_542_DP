package wordTree.threadMgmt;
import wordTree.binarySearchTree.TreeInterface;
import wordTree.util.MyLogger;
import wordTree.util.MyLogger.DebugLevel;

public class DeleteThread implements Runnable
{
    String deleteWord;
    TreeInterface newb;

    /**
     *Constructor
     *@param b, the instance of the tree
     *@param deleteWords, the words to be deleted
     **/
    public DeleteThread(TreeInterface b, String deleteWords){
	deleteWord=deleteWords;
	newb=b;
	MyLogger.writeMessage("in CONSTRUCTOR DeleteThread",DebugLevel.CONSTRUCTOR);
    }

    /**
     *run
     **/
    @Override
    public void run() {
	newb.delete(deleteWord);
	MyLogger.writeMessage("in RunThread delete function",DebugLevel.IN_RUN);
    }
}

