package genericCheckpointing.driver;

import java.lang.Object;
import java.util.Vector;
import java.util.Random;
import genericCheckpointing.util.*;
import genericCheckpointing.xmlStoreRestore.*;
import genericCheckpointing.server.*;
import genericCheckpointing.util.MyLogger;
import genericCheckpointing.util.MyLogger.DebugLevel;
import genericCheckpointing.util.MyAllTypesFirst;
import genericCheckpointing.util.SerializableObject;


public class Driver {
    public static void main(String[] args) {
	try {		
	    if(args.length != 3){
		throw new RuntimeException("error: Invalid arguments");
	    }
	    //---------------------------------------------
	    String mode = args[0]; // mode
	    int size = Integer.parseInt(args[1]); // number of instances	  
	    FileProcessor fileproc = new FileProcessor(args[2]); // file to open
	    //---------------------------------------------
	    ProxyCreator pc = new ProxyCreator();
	    StoreRestoreHandler handler =  new StoreRestoreHandler(fileproc);
	    StoreRestoreI cpointRef = (StoreRestoreI) pc.createProxy(new Class[]{StoreI.class, RestoreI.class},handler);
	    //---------------------------------------------
	    MyAllTypesFirst myFirst;
	    MyAllTypesSecond  mySecond;
	    Vector<SerializableObject> vector_old = new Vector<SerializableObject>();
	    Vector<SerializableObject> vector_new = new Vector<SerializableObject>();
	    // -------------- Serialization Function -----------------------------------
	    if(mode.equals("serdeser")) {
		fileproc.createWriter();
		for (int value=0; value < size; value++) {
		    Random rv = new Random();
		    //-------------- data members for MyAllTypesFirst-----------
		    int myInt = (int) (Math.random()*value);
		    Long myLong = rv.nextLong();
		    String myString = "dinal_herath_"+ myInt +"_typeFirst";
		    boolean myBool = true;
		    if(Math.random() > 0.5){
			myBool = false;
		    }
		    int myOtherInt = (int) (Math.random()*Math.pow(value,2));
		    Long myOtherLong = (Long)(rv.nextLong()*rv.nextInt()*value);
		    //------conditions for MyAllTypesFirst-----------
		    if(myInt < 10){
			myInt = 0;
		    }
		    if(myOtherInt < 10){
			myOtherInt = 0;
		    }
		    if(myLong < 10.0){
			String s = "0";
			myLong = Long.parseLong(s);
		    }
		    if(myOtherLong < 10.0){
			String s = "0";
			myOtherLong = Long.parseLong(s);
		    }
		    //--------------------------------------------------------
		    myFirst = new MyAllTypesFirst(myInt,myLong,myString,myBool,myOtherInt,myOtherLong);		    
		    //--------------- data Members for MyAllTypesSecond--------
		    double myDoubleT = rv.nextDouble();
		    double myOtherDoubleT = rv.nextDouble()*Math.pow(value,2);
		    float myFloatT = rv.nextFloat();
		    short myShortT = (short) (Math.random()*value);
		    short myOtherShortT = (short) (Math.random()*Math.pow(value,2.5));
		    char myCharT = (char) (rv.nextInt(26)+'a');
		    //------- Conditions --------------------
		    if(myDoubleT < 10.0){
			myDoubleT = 0.0;
		    }
		    if(myOtherDoubleT < 10.0){
			myOtherDoubleT = 0.0;
		    }
		    //--------------------------------------------------------
		    mySecond = new MyAllTypesSecond(myDoubleT,myOtherDoubleT,myFloatT,myShortT,myOtherShortT,myCharT);
		    //---------------------------------------------------------
		    ((StoreI) cpointRef).writeObj(myFirst,100,"XML");
		    ((StoreI) cpointRef).writeObj(mySecond,100, "XML");
		    vector_old.add(myFirst);
		    vector_old.add(mySecond);
		}
		fileproc.closeWriter();
	    }
	    fileproc.createReader();
	    for (int j=0; j<2*size; j++) {		
		SerializableObject sObject =  ((RestoreI) cpointRef).readObj("XML");
		if(sObject == null) {
		    break;
		}
		vector_new.add(sObject);
	    }
	    //--------------- Desrialization Function -----------------------------------
	    if(mode.equals("serdeser")) {
		if(verifyVectors(vector_old,vector_new)){
		    System.out.println("0 mismatched objects");
		}
	    }else if(mode.equals("deser")) {
		for(SerializableObject tempObj: vector_new){
		    System.out.println(tempObj.toString());
		}
	    }else{
		System.out.println("Invalid mode");
	    }
	    fileproc.closeReader();
	}catch(RuntimeException e){
	    e.printStackTrace();
	    System.exit(0);
	}finally{}
    }
    
    /**
     *compares between the two vectors
     *@param v_old, the old vector
     *@param v_new, the new vector
     *@return true if same, else false
     **/
    public static boolean verifyVectors(Vector<SerializableObject> v_old, Vector<SerializableObject> v_new){
	boolean flag = false;
	int num = 0;
	int size = 0;
	if(v_old.size() > v_new.size()){
	    size = v_new.size();
	}else{
	    size = v_old.size();  
	}
	for(int i=0;i<size;i++){
	    if(!v_old.get(i).equals(v_new.get(i))){
		num++;
	    }
	}
	if(num != 0){
	    System.out.println("Number of mismatches: "+num);
	}else{
	    flag = true;
	}
	return flag;
    }
}

